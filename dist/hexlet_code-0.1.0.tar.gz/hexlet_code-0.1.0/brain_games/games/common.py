def greetting(name) -> None:
        """
        Greetting
        """
        print("Welcome to the Brain Games!")
        print(f"Hello, {name}!")
        
def question(object_) -> None:
    """
    question number is even
    """
    print(f'Question: {object_}')
