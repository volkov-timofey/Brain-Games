### Hexlet tests and linter status:
[![Actions Status](https://github.com/volkov-timofey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/volkov-timofey/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability)](https://codeclimate.com/github/volkov-timofey/python-project-49/maintainability)

+ Brain-even (Step 5) - presentation [asciinema](https://asciinema.org/a/QIU7LvvlH6rnS855Z00wljgAp?t=36)
+ Brain-calc (Step 6) - presentation [asciinema](https://asciinema.org/a/nzoOcuYTgL4NZTroig00LjYBC?t=1:24)

