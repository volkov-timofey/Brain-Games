# count rounds
count = 3

# calc
max_value_calc = 500

# progression
max_progr_num = 20
max_diff = 10
min_diff = 2
max_len = 10
min_len = 6

# prime
max_value_prime = 50

#gcd
max_value_gcd = 100

#even
max_value_even = 500