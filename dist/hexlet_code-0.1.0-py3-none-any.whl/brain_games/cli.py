import prompt


def welcome_user():
    """
    Function greeting
    """
    name = prompt.string('May I have your name? ')
    print(f"Hello, {name}!")
